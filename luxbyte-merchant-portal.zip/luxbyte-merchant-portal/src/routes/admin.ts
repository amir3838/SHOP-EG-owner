import { Router } from 'express';
import * as bcrypt from 'bcrypt';
import { z } from 'zod';
import { prisma } from '../prisma/client.js';
import { signAdminJWT, authRequired, setAuthCookie, clearAuthCookie } from '../middlewares/auth.js';
import { ApplicationListQuerySchema } from '../utils/validators.js';
import { toCSV } from '../utils/csv.js';
import { logAudit } from '../services/audit.js';

const router = Router();

// ===== Auth =====
const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = LoginSchema.parse(req.body);
    const admin = await prisma.admin.findUnique({ where: { email } });
    if (!admin) {
      return res.status(401).json({ ok: false, error: 'Invalid credentials' });
    }
    const ok = await bcrypt.compare(password, admin.passHash);
    if (!ok) {
      return res.status(401).json({ ok: false, error: 'Invalid credentials' });
    }
    const token = signAdminJWT({ id: admin.id, email: admin.email, role: admin.role });
    setAuthCookie(res, token);
    await logAudit({ actor: admin.email, action: 'admin.login', entity: `admin:${admin.id}` });
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', authRequired as any, async (req, res) => {
  // @ts-expect-error injected by auth middleware
  const actor = req.user?.email ?? 'system';
  clearAuthCookie(res);
  await logAudit({ actor, action: 'admin.logout', entity: 'admin:self' });
  res.json({ ok: true });
});

router.get('/me', authRequired as any, async (req, res) => {
  // @ts-expect-error injected by auth middleware
  const u = req.user;
  res.json({ id: u.id, email: u.email, role: u.role });
});

// ===== Applications list for admin =====
router.get('/applications', authRequired as any, async (req, res, next) => {
  try {
    const q = ApplicationListQuerySchema.parse(req.query);
    const where: any = {};
    if (q.type) where.type = q.type;
    if (q.status) where.status = q.status;
    if (q.gov) where.gov = q.gov;
    if (q.city) where.city = q.city;
    if (q.q) {
      where.OR = [
        { storeName: { contains: q.q, mode: 'insensitive' } },
        { email: { contains: q.q, mode: 'insensitive' } },
        { phone: { contains: q.q, mode: 'insensitive' } }
      ];
    }

    const [items, total] = await Promise.all([
      prisma.application.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (q.page - 1) * q.pageSize,
        take: q.pageSize,
        include: {
          documents: true
        }
      }),
      prisma.application.count({ where })
    ]);

    res.json({
      items,
      page: q.page,
      pageSize: q.pageSize,
      total,
      pages: Math.ceil(total / q.pageSize)
    });
  } catch (err) {
    next(err);
  }
});

router.get('/applications/:id', authRequired as any, async (req, res, next) => {
  try {
    const app = await prisma.application.findUnique({
      where: { id: req.params.id },
      include: { documents: true }
    });
    if (!app) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json(app);
  } catch (err) {
    next(err);
  }
});

// ===== Audit logs =====
router.get('/audit', authRequired as any, async (req, res, next) => {
  try {
    const page = Number(req.query.page ?? 1);
    const pageSize = Number(req.query.pageSize ?? 20);
    const [items, total] = await Promise.all([
      prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      prisma.auditLog.count()
    ]);
    res.json({ items, page, pageSize, total, pages: Math.ceil(total / pageSize) });
  } catch (err) {
    next(err);
  }
});

// ===== Export CSV =====
router.get('/export.csv', authRequired as any, async (req, res, next) => {
  try {
    const q = ApplicationListQuerySchema.parse(req.query);
    const where: any = {};
    if (q.type) where.type = q.type;
    if (q.status) where.status = q.status;
    if (q.gov) where.gov = q.gov;
    if (q.city) where.city = q.city;

    const items = await prisma.application.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 5000
    });

    const rows = items.map((a: any) => ({
      id: a.id,
      type: a.type,
      store_name: a.storeName,
      email: a.email,
      phone: a.phone,
      gov: a.gov,
      city: a.city,
      status: a.status,
      created_at: a.createdAt.toISOString()
    }));

    const csv = toCSV(rows);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="applications.csv"');
    res.send(csv);
  } catch (err) {
    next(err);
  }
});

export default router;
