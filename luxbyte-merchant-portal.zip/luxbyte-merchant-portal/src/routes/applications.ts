import { Router } from 'express';
import { prisma } from '../prisma/client.js';
import { ApplicationCreateSchema, ApplicationListQuerySchema, ApplicationPatchSchema } from '../utils/validators.js';
import { notifyNewApplication } from '../services/notifications.js';
import { authRequired } from '../middlewares/auth.js';
import { logAudit } from '../services/audit.js';

const router = Router();

// POST /applications -> create application after email verification
router.post('/', async (req, res, next) => {
  try {
    const input = ApplicationCreateSchema.parse(req.body);

    // verification must exist and be verified for the same email
    const vr = await prisma.verification.findUnique({
      where: { requestId: input.verificationRequestId }
    });

    if (!vr || vr.email !== input.email || vr.status !== 'verified') {
      const err = new Error('البريد غير مُؤكَّد. الرجاء إتمام خطوة التحقق عبر البريد.');
      (err as any).status = 400;
      throw err;
    }

    const created = await prisma.application.create({
      data: {
        type: input.type,
        storeName: input.storeName,
        email: input.email,
        phone: input.phone,
        gov: input.gov,
        city: input.city,
        addressText: input.addressText,
        lat: input.lat,
        lng: input.lng,
        documents: {
          create: input.documents.map(d => ({
            kind: d.kind,
            fileUrl: d.fileUrl,
            mime: d.mime,
            size: d.size,
            sha256: d.sha256
          }))
        }
      },
      include: { documents: true }
    });

    // notify team
    await notifyNewApplication({
      id: created.id,
      type: created.type,
      storeName: created.storeName,
      email: created.email,
      gov: created.gov,
      city: created.city
    }).catch(() => { /* ignore notify failure */ });

    res.status(201).json({ id: created.id });
  } catch (err: any) {
    // unique email violation
    if (err?.code === 'P2002') {
      err.status = 409;
      err.message = 'هذا البريد مستخدم في طلب سابق';
    }
    next(err);
  }
});

// GET /applications/:id -> get single application (public read-only)
router.get('/:id', async (req, res, next) => {
  try {
    const app = await prisma.application.findUnique({
      where: { id: req.params.id },
      include: { documents: true }
    });
    if (!app) {
      return res.status(404).json({ ok: false, error: 'الطلب غير موجود' });
    }
    res.json(app);
  } catch (err) {
    next(err);
  }
});

// GET /applications -> list with filters (public basic list)
router.get('/', async (req, res, next) => {
  try {
    const q = ApplicationListQuerySchema.parse(req.query);
    const where: any = {};
    if (q.type) where.type = q.type;
    if (q.status) where.status = q.status;
    if (q.gov) where.gov = q.gov;
    if (q.city) where.city = q.city;
    if (q.q) {
      where.OR = [
        { storeName: { contains: q.q, mode: 'insensitive' } },
        { email: { contains: q.q, mode: 'insensitive' } },
        { phone: { contains: q.q, mode: 'insensitive' } }
      ];
    }

    const [items, total] = await Promise.all([
      prisma.application.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (q.page - 1) * q.pageSize,
        take: q.pageSize,
        select: {
          id: true,
          type: true,
          storeName: true,
          email: true,
          phone: true,
          gov: true,
          city: true,
          status: true,
          createdAt: true
        }
      }),
      prisma.application.count({ where })
    ]);

    res.json({
      items,
      page: q.page,
      pageSize: q.pageSize,
      total,
      pages: Math.ceil(total / q.pageSize)
    });
  } catch (err) {
    next(err);
  }
});

// PATCH /applications/:id -> admin change status/note
router.patch('/:id', authRequired, async (req, res, next) => {
  try {
    const data = ApplicationPatchSchema.parse(req.body);
    const updated = await prisma.application.update({
      where: { id: req.params.id },
      data
    });

    // @ts-expect-error injected by auth middleware
    const actorEmail = req.user?.email ?? 'system';
    await logAudit({
      actor: actorEmail,
      action: 'application.update',
      entity: `application:${updated.id}`,
      meta: data
    });

    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
