import { Router } from 'express';
import { UploadSignSchema } from '../utils/validators.js';
import { SupabaseStorage } from '../services/storage/SupabaseStorage.js';

const router = Router();

router.post('/sign', async (req, res, next) => {
  try {
    const input = UploadSignSchema.parse(req.body);
    const storage = new SupabaseStorage();
    const { url, fields, maxSize, key } = await storage.signUpload(input);
    const publicUrl = storage.publicUrl(key);
    res.json({ url, fields, key, publicUrl, maxSize });
  } catch (err) {
    next(err);
  }
});

export default router;
