import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import compression from 'compression';
import path from 'path';
import { fileURLToPath } from 'url';

import { config } from './config/env.js';
import { errorHandler } from './middlewares/errorHandler.js';

// Routes (to be implemented in subsequent steps)
import verifyRouter from './routes/verify.js';
import uploadsRouter from './routes/uploads.js';
import applicationsRouter from './routes/applications.js';
import adminRouter from './routes/admin.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Security headers
app.use(helmet({
  contentSecurityPolicy: false // keep simple for dev; may enable with proper directives later
}));

// CORS
const allowed = new Set(config.security.corsOrigins);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);
    if (allowed.has(origin)) return cb(null, true);
    return cb(new Error('CORS: Origin not allowed'), false);
  },
  credentials: true
}));

// Parsers
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Gzip
app.use(compression());

// Static frontend (served by the same server)
const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir, { extensions: ['html'] }));

// Health check
app.get('/health', (_req, res) => res.json({ ok: true, env: config.nodeEnv }));

// REST APIs (no /api prefix to match the spec)
app.use('/verify', verifyRouter);
app.use('/uploads', uploadsRouter);
app.use('/applications', applicationsRouter);
app.use('/admin', adminRouter);

// Fallback to index.html for root
app.get('/', (_req, res) => {
  res.sendFile(path.join(publicDir, 'index.html'));
});

// Error handler (last)
app.use(errorHandler);

// Bootstrap
app.listen(config.port, () => {
  // eslint-disable-next-line no-console
  console.log(`Luxbyte Merchant Portal running on http://localhost:${config.port}`);
});
