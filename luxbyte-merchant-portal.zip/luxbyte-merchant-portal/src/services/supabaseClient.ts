import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import 'dotenv/config';

/**
 * Supabase client bootstrap (server-side).
 *
 * Usage:
 *   import { getSupabase, supabaseAnon, supabaseService } from './services/supabaseClient.js';
 *   const supabase = getSupabase('service');
 *   const { data, error } = await supabase.from('some_table').select('*');
 *
 * Env vars required:
 *   SUPABASE_URL=https://<project-ref>.supabase.co
 *   SUPABASE_ANON_KEY=...            (optional, for public operations)
 *   SUPABASE_SERVICE_ROLE_KEY=...    (recommended for server-side privileged ops)
 */
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://mizvmxgiyrnfnrxjhqpe.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

// Create clients if keys are present. We do not throw on missing keys to keep
// the server boot resilient; callers can check for null if needed.
export const supabaseAnon: SupabaseClient | null = SUPABASE_ANON_KEY
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

export const supabaseService: SupabaseClient | null = SUPABASE_SERVICE_ROLE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
  : null;

/**
 * Returns a Supabase client. Defaults to 'service' to enable server-side features.
 * If the requested client is not configured, this function throws with a clear message.
 */
export function getSupabase(kind: 'anon' | 'service' = 'service'): SupabaseClient {
  if (kind === 'service') {
    if (!supabaseService) {
      throw new Error('SUPABASE_SERVICE_ROLE_KEY is not set. Provide it in your .env to enable privileged Supabase operations.');
    }
    return supabaseService;
  }
  if (!supabaseAnon) {
    throw new Error('SUPABASE_ANON_KEY is not set. Provide it in your .env to enable public Supabase operations.');
  }
  return supabaseAnon;
}

// Small self-test (only runs when executed directly, not when imported)
if (process.env.NODE_ENV === 'development' && process.env.SUPABASE_URL && (SUPABASE_ANON_KEY || SUPABASE_SERVICE_ROLE_KEY)) {
  // eslint-disable-next-line no-console
  console.log(`[supabase] Initialized (${SUPABASE_ANON_KEY ? 'anon' : ''}${SUPABASE_ANON_KEY && SUPABASE_SERVICE_ROLE_KEY ? ' + ' : ''}${SUPABASE_SERVICE_ROLE_KEY ? 'service' : ''}) -> ${SUPABASE_URL}`);
}
