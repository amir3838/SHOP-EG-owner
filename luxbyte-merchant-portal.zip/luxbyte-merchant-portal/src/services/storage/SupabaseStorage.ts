import { S3Client } from '@aws-sdk/client-s3';
import { createPresignedPost, PresignedPost } from '@aws-sdk/s3-presigned-post';
import { v4 as uuidv4 } from 'uuid';
import { config } from '../../config/env.js';

export type SignUploadParams = {
  fileName: string;
  mime: string;
  scope:
    | 'sign_photo'
    | 'ph_license'
    | 'ph_cr'
    | 'ph_id'
    | 'sm_id'
    | 'sm_cr'
    | 'sm_tax';
};

export class SupabaseStorage {
  private s3: S3Client;

  constructor() {
    this.s3 = new S3Client({
      region: config.storage.region,
      endpoint: config.storage.endpoint,
      credentials: {
        accessKeyId: config.storage.accessKeyId,
        secretAccessKey: config.storage.secretAccessKey
      },
      forcePathStyle: true
    });
  }

  async signUpload(params: SignUploadParams): Promise<{
    url: string;
    fields: PresignedPost['fields'];
    maxSize: number;
    key: string;
  }> {
    // Narrow type for includes and guard against invalid mime values
    const allowed = config.storage.allowedMime as readonly string[];
    if (!allowed.includes(params.mime)) {
      throw Object.assign(new Error('نوع الملف غير مسموح'), { status: 400 });
    }

    const safeName = params.fileName.replace(/[^a-zA-Z0-9._-]+/g, '_');
    const key = `${params.scope}/${uuidv4()}_${safeName}`;

    const post = await createPresignedPost(this.s3, {
      Bucket: config.storage.bucket,
      Key: key,
      Conditions: [
        ['content-length-range', 0, config.storage.maxFileSizeBytes],
        // Cast to any to satisfy literal union narrowing in AWS SDK types
        ['eq', '$Content-Type', params.mime as any]
      ],
      Fields: {
        // Ditto cast for strict literal union types
        'Content-Type': params.mime as any
      },
      Expires: 600 // 10 minutes
    });

    return {
      url: post.url,
      fields: post.fields,
      maxSize: config.storage.maxFileSizeBytes,
      key
    };
  }

  publicUrl(key: string): string {
    // Supabase S3 public URL pattern when bucket is public or via signed serve
    // For simplicity we return the S3 endpoint path-style URL
    const endpoint = new URL(config.storage.endpoint);
    return `${endpoint.origin}/${config.storage.bucket}/${key}`;
  }
}
