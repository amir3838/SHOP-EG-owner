import type { EmailService, SendEmailParams } from './EmailService.js';

export class DevEmailService implements EmailService {
  async send(params: SendEmailParams): Promise<void> {
    // eslint-disable-next-line no-console
    console.log('[DEV EMAIL] =============================');
    // eslint-disable-next-line no-console
    console.log('To:', params.to);
    // eslint-disable-next-line no-console
    console.log('Subject:', params.subject);
    // eslint-disable-next-line no-console
    console.log('Text:', params.text || '(no text)');
    // eslint-disable-next-line no-console
    console.log('HTML:', params.html);
    // eslint-disable-next-line no-console
    console.log('========================================');
  }
}
