import nodemailer from 'nodemailer';
import type { EmailService, SendEmailParams } from './EmailService.js';
import { config } from '../../config/env.js';

export class SmtpEmailService implements EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    if (!config.email.smtp.host || !config.email.smtp.user || !config.email.smtp.pass) {
      throw new Error('SMTP configuration is incomplete');
    }
    this.transporter = nodemailer.createTransport({
      host: config.email.smtp.host,
      port: config.email.smtp.port,
      secure: config.email.smtp.port === 465,
      auth: {
        user: config.email.smtp.user,
        pass: config.email.smtp.pass
      }
    });
  }

  async send(params: SendEmailParams): Promise<void> {
    const from = params.from ?? config.email.from;
    await this.transporter.sendMail({
      from,
      to: params.to,
      subject: params.subject,
      html: params.html,
      text: params.text
    });
  }
}
