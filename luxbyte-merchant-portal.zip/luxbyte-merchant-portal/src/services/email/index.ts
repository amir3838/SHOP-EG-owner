import { config } from '../../config/env.js';
import type { EmailService } from './EmailService.js';
import { ResendEmailService } from './ResendEmailService.js';
import { SmtpEmailService } from './SmtpEmailService.js';
import { DevEmailService } from './DevEmailService.js';

let cached: EmailService | null = null;

export function getEmailService(): EmailService {
  if (cached) return cached;

  const provider = config.email.provider;

  // Force dev provider if explicitly chosen, or if resend is selected without key in non-prod
  if (provider === 'dev' || (!config.isProd && provider === 'resend' && !config.email.resendApiKey)) {
    cached = new DevEmailService();
    return cached;
  }

  try {
    if (provider === 'resend') {
      cached = new ResendEmailService();
    } else if (provider === 'smtp') {
      cached = new SmtpEmailService();
    } else {
      // Fallback safe
      cached = new DevEmailService();
    }
  } catch (e) {
    if (!config.isProd) {
      cached = new DevEmailService();
    } else {
      throw e;
    }
  }

  return cached;
}
