import { Resend } from 'resend';
import type { EmailService, SendEmailParams } from './EmailService.js';
import { config } from '../../config/env.js';

export class ResendEmailService implements EmailService {
  private client: Resend;

  constructor(apiKey = config.email.resendApiKey) {
    if (!apiKey) {
      throw new Error('RESEND_API_KEY is required for ResendEmailService');
    }
    this.client = new Resend(apiKey);
  }

  async send(params: SendEmailParams): Promise<void> {
    const from = params.from ?? config.email.from;
    const to = Array.isArray(params.to) ? params.to : [params.to];

    const result = await this.client.emails.send({
      from,
      to,
      subject: params.subject,
      html: params.html,
      text: params.text
    });

    if (result.error) {
      throw new Error(`Resend send error: ${result.error.message}`);
    }
  }
}
