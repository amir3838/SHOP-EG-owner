export type SendEmailParams = {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  from?: string;
};

export interface EmailService {
  send(params: SendEmailParams): Promise<void>;
}

// بسيط: قالب بريد تحقق عربي
export function verificationEmailTemplate(link: string) {
  const html = `
  <div style="direction:rtl;font-family:Tahoma,Arial,sans-serif;line-height:1.8">
    <h2>تأكيد البريد الإلكتروني</h2>
    <p>مرحبًا،</p>
    <p>اضغط على الزر التالي لتأكيد بريدك الإلكتروني واستكمال التسجيل في منصة توكيد التجار:</p>
    <p>
      <a href="${link}" style="background:#e11d48;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">
        تأكيد البريد الآن
      </a>
    </p>
    <p>هذا الرابط صالح لمدة 10 دقائق وبحد أقصى 5 محاولات.</p>
    <p>شركة لوكس بايت ش.ذ.م.م — “هنكبر مع بعض”.</p>
  </div>`;
  const text = `تأكيد البريد الإلكتروني\n\nيرجى فتح الرابط التالي خلال 10 دقائق:\n${link}\n\nشركة لوكس بايت — هنكبر مع بعض.`;
  return { html, text };
}
