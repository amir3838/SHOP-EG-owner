import { addMinutes, isAfter } from 'date-fns';
import { prisma } from '../prisma/client.js';
import { randomToken, sha256, timingSafeEqual } from '../utils/crypto.js';
import { getEmailService } from './email/index.js';
import { verificationEmailTemplate } from './email/EmailService.js';
import { config } from '../config/env.js';

const MAX_ATTEMPTS = 5;
const EXPIRES_MINUTES = 10;

export async function createVerification(email: string): Promise<{ requestId: string }> {
  const token = randomToken(16);
  const tokenHash = sha256(token);
  const expiresAt = addMinutes(new Date(), EXPIRES_MINUTES);

  // استخدم requestId مستقل عن id لسهولة مشاركته
  const requestId = randomToken(8);

  await prisma.verification.create({
    data: {
      requestId,
      email,
      tokenHash,
      expiresAt,
      status: 'pending'
    }
  });

  const link = new URL('/verify.html', config.appUrl);
  link.searchParams.set('requestId', requestId);
  link.searchParams.set('token', token);

  const { html, text } = verificationEmailTemplate(link.toString());
  const emailService = getEmailService();
  await emailService.send({
    to: email,
    subject: 'تأكيد البريد الإلكتروني - منصة توكيد التجار',
    html,
    text
  });

  // لا نعيد الـ token إطلاقًا؛ يتم إرساله فقط داخل البريد
  return { requestId };
}

export async function confirmVerification(requestId: string, token: string): Promise<{ ok: true }> {
  const v = await prisma.verification.findUnique({ where: { requestId } });
  if (!v) {
    const err = new Error('طلب تحقق غير موجود');
    (err as any).status = 400;
    throw err;
  }

  if (v.status === 'verified') {
    return { ok: true };
  }

  if (v.attempts >= MAX_ATTEMPTS) {
    await prisma.verification.update({
      where: { requestId },
      data: { status: 'expired' }
    });
    const err = new Error('تم تجاوز الحد الأقصى للمحاولات');
    (err as any).status = 429;
    throw err;
  }

  if (isAfter(new Date(), v.expiresAt)) {
    await prisma.verification.update({
      where: { requestId },
      data: { status: 'expired' }
    });
    const err = new Error('انتهت صلاحية الرابط');
    (err as any).status = 400;
    throw err;
  }

  const valid = timingSafeEqual(sha256(token), v.tokenHash);

  if (!valid) {
    // زيادة عدد المحاولات فقط عند الخطأ
    await prisma.verification.update({
      where: { requestId },
      data: { attempts: { increment: 1 } }
    });
    const err = new Error('رمز غير صحيح');
    (err as any).status = 400;
    throw err;
  }

  // نجاح: تأكيد بدون زيادة attempts
  await prisma.verification.update({
    where: { requestId },
    data: { status: 'verified' }
  });

  return { ok: true };
}
