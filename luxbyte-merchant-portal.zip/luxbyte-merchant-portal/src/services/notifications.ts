import { getEmailService } from './email/index.js';
import { config } from '../config/env.js';

export async function notifyNewApplication(app: {
  id: string;
  type: string;
  storeName: string;
  email: string;
  gov: string;
  city: string;
}) {
  if (!config.notify.admins.length) return;

  const subject = `طلب جديد (#${app.id}) - ${app.storeName}`;
  const html = `
  <div style="direction:rtl;font-family:Tahoma,Arial,sans-serif;line-height:1.8">
    <h3>تم استلام طلب جديد</h3>
    <ul>
      <li>رقم الطلب: ${app.id}</li>
      <li>نوع النشاط: ${app.type}</li>
      <li>اسم المتجر: ${app.storeName}</li>
      <li>البريد: ${app.email}</li>
      <li>المحافظة/المدينة: ${app.gov} / ${app.city}</li>
    </ul>
    <p>يرجى مراجعة لوحة الإدارة لاتخاذ الإجراء المناسب.</p>
  </div>
  `;
  const text = `طلب جديد: #${app.id}\n${app.type} - ${app.storeName}\n${app.email}\n${app.gov}/${app.city}`;
  const email = getEmailService();
  await email.send({
    to: config.notify.admins,
    subject,
    html,
    text
  });
}
