import { prisma } from '../prisma/client.js';

export async function logAudit(params: {
  actor: string;
  action: string;
  entity: string;
  meta?: unknown;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        actor: params.actor,
        action: params.action,
        entity: params.entity,
        meta: params.meta as any
      }
    });
  } catch {
    // لا توقف التدفق بسبب خطأ في السجل
  }
}
