export function toCSV(rows: Record<string, unknown>[], headers?: string[]): string {
  if (!rows.length) return '';
  const keys = headers ?? Object.keys(rows[0]);
  const esc = (v: unknown) => {
    const s = v == null ? '' : String(v);
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const lines = [
    keys.join(','),
    ...rows.map(r => keys.map(k => esc(r[k])).join(','))
  ];
  // Add BOM for Excel compatibility
  return '\uFEFF' + lines.join('\n');
}
