import { z } from 'zod';
import { isValidGovCity, listCities, listGovs } from './govCity.js';

// ===== Shared enums =====
export const ApplicationTypeEnum = z.enum(['pharmacy', 'supermarket', 'restaurant']);
export const ApplicationStatusEnum = z.enum(['pending', 'in_review', 'approved', 'rejected']);
export const DocumentKindEnum = z.enum([
  'sign_photo',
  'ph_license',
  'ph_cr',
  'ph_id',
  'sm_id',
  'sm_cr',
  'sm_tax'
]);

// ===== Common validations =====
export const E164Phone = z.string().regex(/^\+[1-9]\d{1,14}$/, 'الهاتف يجب أن يكون بصيغة E.164 مثل +201234567890');

export const GovSchema = z.string().refine(
  (gov) => listGovs().includes(gov),
  { message: 'المحافظة غير صحيحة' }
);

export const CitySchema = z.object({
  gov: z.string(),
  city: z.string()
}).refine(
  (v) => isValidGovCity(v.gov, v.city),
  {
    message: 'المدينة غير صحيحة لهذه المحافظة'
  }
);

// ===== Verify endpoints =====
export const VerifySendSchema = z.object({
  email: z.string().email('بريد إلكتروني غير صالح')
});

export const VerifyConfirmSchema = z.object({
  requestId: z.string().min(1, 'requestId مطلوب'),
  token: z.string().min(1, 'token مطلوب')
});

// ===== Upload sign =====
export const UploadSignSchema = z.object({
  fileName: z.string().min(1),
  mime: z.string().min(1),
  scope: DocumentKindEnum
});

// ===== Application documents =====
export const DocumentInputSchema = z.object({
  kind: DocumentKindEnum,
  fileUrl: z.string().url(),
  mime: z.string().min(1),
  size: z.number().int().positive(),
  sha256: z.string().length(64) // hex sha256
});

export type DocumentInput = z.infer<typeof DocumentInputSchema>;

// Kitchen tags for restaurants
export const KitchenTagEnum = z.enum([
  'فطار مصري',
  'سوري',
  'شرقي',
  'مشويات',
  'بحري',
  'فاست فود',
  'حلويات',
  'كافيه'
]);

// ===== Application create =====
export const ApplicationCreateSchema = z.object({
  type: ApplicationTypeEnum,
  storeName: z.string().min(2).max(120),
  email: z.string().email(),
  phone: E164Phone,
  gov: GovSchema,
  city: z.string().min(1),
  addressText: z.string().min(5).max(500),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),

  // From verify flow
  verificationRequestId: z.string().min(1),

  // Documents uploaded to storage (presigned)
  documents: z.array(DocumentInputSchema).min(1),

  // Restaurant only
  kitchenTypes: z.array(KitchenTagEnum).optional()
}).superRefine((data, ctx) => {
  // validate city against governorate
  if (!isValidGovCity(data.gov, data.city)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['city'],
      message: 'المدينة غير صحيحة لهذه المحافظة'
    });
  }

  // require sign_photo for all
  const hasSign = data.documents.some(d => d.kind === 'sign_photo');
  if (!hasSign) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['documents'],
      message: 'صورة يافطة المتجر إلزامية'
    });
  }

  // per-type required documents
  const has = (k: string) => data.documents.some(d => d.kind === k);
  if (data.type === 'pharmacy') {
    if (!has('ph_license') || !has('ph_cr') || !has('ph_id')) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['documents'],
        message: 'صيدلية: مطلوب رخصة صيدلية + سجل تجاري + بطاقة مسؤول'
      });
    }
  } else if (data.type === 'supermarket') {
    if (!has('sm_id')) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['documents'],
        message: 'سوبر ماركت: بطاقة مسؤول إلزامية؛ السجل التجاري والبطاقة الضريبية اختياريان'
      });
    }
  } else if (data.type === 'restaurant') {
    if (!has('sm_id')) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['documents'],
        message: 'مطعم: بطاقة مسؤول إلزامية'
      });
    }
    if (!data.kitchenTypes || data.kitchenTypes.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['kitchenTypes'],
        message: 'مطعم: يجب اختيار نوع/أنواع المطبخ'
      });
    }
  }
});

export type ApplicationCreateInput = z.infer<typeof ApplicationCreateSchema>;

export const ApplicationListQuerySchema = z.object({
  type: ApplicationTypeEnum.optional(),
  status: ApplicationStatusEnum.optional(),
  gov: z.string().optional(),
  city: z.string().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  q: z.string().optional()
});

export const ApplicationPatchSchema = z.object({
  status: ApplicationStatusEnum.optional(),
  reviewNote: z.string().max(1000).optional()
}).refine(d => d.status || d.reviewNote, {
  message: 'يجب تحديد حالة أو إضافة ملاحظة'
});
