import 'dotenv/config';
import { z } from 'zod';

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'production']).default('development'),
  PORT: z.coerce.number().default(4001),

  APP_URL: z.string().url().default('http://localhost:4000'),

  // Database
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  DIRECT_URL: z.string().min(1, 'DIRECT_URL is required'),

  // S3-compatible Supabase Storage
  S3_ENDPOINT: z.string().url(),
  S3_REGION: z.string().default('us-east-1'),
  S3_ACCESS_KEY_ID: z.string().min(1, 'S3_ACCESS_KEY_ID is required'),
  S3_SECRET_ACCESS_KEY: z.string().min(1, 'S3_SECRET_ACCESS_KEY is required'),
  STORAGE_BUCKET: z.string().default('merchant-documents'),

  // Email
  EMAIL_PROVIDER: z.enum(['resend', 'smtp', 'dev']).default('resend'),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default('Luxbyte LLC <no-reply@example.com>'),

  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().optional(),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),

  // Admin notifications
  ADMIN_NOTIFY_EMAILS: z.string().default(''),

  // Security
  JWT_SECRET: z.string().min(16, 'JWT_SECRET should be long and random'),
  CSRF_SECRET: z.string().min(16, 'CSRF_SECRET should be long and random'),
  CORS_ORIGINS: z.string().default('http://localhost:4000'),

  // Turnstile (optional)
  TURNSTILE_SITE_KEY: z.string().optional(),
  TURNSTILE_SECRET_KEY: z.string().optional(),

  // Rate limit
  RATE_LIMIT_WINDOW_MS: z.coerce.number().default(60_000),
  RATE_LIMIT_MAX: z.coerce.number().default(10)
});

const parsed = EnvSchema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error('Invalid environment variables:', parsed.error.flatten().fieldErrors);
  throw new Error('Environment validation failed');
}

const env = parsed.data;

export const config = {
  nodeEnv: env.NODE_ENV,
  isProd: env.NODE_ENV === 'production',
  port: env.PORT,

  appUrl: env.APP_URL,

  db: {
    url: env.DATABASE_URL,
    directUrl: env.DIRECT_URL
  },

  storage: {
    endpoint: env.S3_ENDPOINT,
    region: env.S3_REGION,
    accessKeyId: env.S3_ACCESS_KEY_ID,
    secretAccessKey: env.S3_SECRET_ACCESS_KEY,
    bucket: env.STORAGE_BUCKET,
    // Max upload size 10MB
    maxFileSizeBytes: 10 * 1024 * 1024,
    allowedMime: [
      'image/jpeg',
      'image/png',
      'application/pdf'
    ]
  },

  email: {
    provider: env.EMAIL_PROVIDER,
    resendApiKey: env.RESEND_API_KEY,
    from: env.EMAIL_FROM,
    smtp: {
      host: env.SMTP_HOST,
      port: env.SMTP_PORT ?? 587,
      user: env.SMTP_USER,
      pass: env.SMTP_PASS
    }
  },

  notify: {
    admins: env.ADMIN_NOTIFY_EMAILS.split(',').map(s => s.trim()).filter(Boolean)
  },

  security: {
    jwtSecret: env.JWT_SECRET,
    csrfSecret: env.CSRF_SECRET,
    corsOrigins: env.CORS_ORIGINS.split(',').map(s => s.trim()).filter(Boolean),
    turnstile: {
      siteKey: env.TURNSTILE_SITE_KEY,
      secretKey: env.TURNSTILE_SECRET_KEY
    }
  },

  rateLimit: {
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    max: env.RATE_LIMIT_MAX
  }
} as const;

export type AppConfig = typeof config;
