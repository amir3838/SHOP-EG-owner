import type { NextFunction, Request, Response } from 'express';

type HttpError = Error & { status?: number; code?: string; details?: unknown };

export function errorHandler(err: HttpError, _req: Request, res: Response, _next: NextFunction) {
  const status = err.status && Number.isInteger(err.status) ? err.status : 500;

  const payload: Record<string, unknown> = {
    ok: false,
    error: err.message || 'Internal Server Error'
  };

  if (process.env.NODE_ENV !== 'production') {
    payload.stack = err.stack;
    payload.code = err.code;
    if (err.details) payload.details = err.details;
  }

  res.status(status).json(payload);
}
