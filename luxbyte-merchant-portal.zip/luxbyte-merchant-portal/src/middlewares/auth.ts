import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config/env.js';

export type AdminJwtPayload = {
  id: string;
  email: string;
  role: 'reviewer' | 'admin';
};

const COOKIE_NAME = 'admin_token';

export function signAdminJWT(payload: AdminJwtPayload): string {
  return jwt.sign(payload, config.security.jwtSecret, { expiresIn: '7d' });
}

export function parseToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) {
    return header.slice('Bearer '.length);
  }
  const cookie = req.cookies?.[COOKIE_NAME];
  return cookie ?? null;
}

export function authRequired(req: Request, res: Response, next: NextFunction) {
  const token = parseToken(req);
  if (!token) {
    return res.status(401).json({ ok: false, error: 'Authentication required' });
  }
  try {
    const payload = jwt.verify(token, config.security.jwtSecret) as AdminJwtPayload;
    // @ts-expect-error attach user to request dynamically
    req.user = payload;
    return next();
  } catch {
    return res.status(401).json({ ok: false, error: 'Invalid token' });
  }
}

export function setAuthCookie(res: Response, token: string) {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    secure: config.isProd,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000
  });
}

export function clearAuthCookie(res: Response) {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    secure: config.isProd,
    sameSite: 'lax'
  });
}
