import rateLimit from 'express-rate-limit';
import type { RequestHandler } from 'express';
import { config } from '../config/env.js';

export const verifySendLimiter: RequestHandler = rateLimit({
  windowMs: config.rateLimit.windowMs, // مثل 60 ثانية
  max: config.rateLimit.max,           // مثل 10 محاولات
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const ip = req.ip || req.headers['x-forwarded-for']?.toString() || 'unknown';
    const email = (req.body?.email as string) || '';
    return `verify-send:${ip}:${email}`;
  },
  message: { ok: false, error: 'Too many requests, please try again later.' }
});

export const verifyConfirmLimiter: RequestHandler = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const ip = req.ip || req.headers['x-forwarded-for']?.toString() || 'unknown';
    const requestId = (req.body?.requestId as string) || '';
    return `verify-confirm:${ip}:${requestId}`;
  },
  message: { ok: false, error: 'Too many requests, please try again later.' }
});
