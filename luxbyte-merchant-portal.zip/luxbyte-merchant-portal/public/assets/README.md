Place your branding assets here.

- logo.png: Put the Luxbyte logo file here as public/assets/logo.png (used by splash, header and footer).
- You can also add additional images/icons as needed.

Notes:
- The UI is RTL and uses the brand colors derived from the provided logo.
- Footer displays: “42 شارع البحر، شيراتون، القاهرة – الدور الخامس” and خدمة العملاء: +201148709609.
