/* Leaflet map + reverse geocoding (Nominatim) */
(function(){
  function initMap({ mapId = 'map', latInputId = 'lat', lngInputId = 'lng', addressInputId = 'addressText', useMyLocationBtnId = 'useMyLocation' } = {}) {
    const latEl = document.getElementById(latInputId);
    const lngEl = document.getElementById(lngInputId);
    const addressEl = document.getElementById(addressInputId);
    const mapEl = document.getElementById(mapId);

    if (!mapEl) return;

    const cairo = [30.0444, 31.2357];
    const map = L.map(mapId, { scrollWheelZoom: true }).setView(cairo, 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    let marker = L.marker(cairo, { draggable: true }).addTo(map);

    function setPos(lat, lng, move = true) {
      if (move) {
        marker.setLatLng([lat, lng]);
        map.setView([lat, lng], map.getZoom());
      }
      if (latEl) latEl.value = String(lat);
      if (lngEl) lngEl.value = String(lng);
    }

    async function reverseGeocode(lat, lng) {
      try {
        const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=ar`;
        const res = await fetch(url, { headers: { 'User-Agent': 'Luxbyte-Merchant-Portal' } });
        const data = await res.json();
        if (addressEl && data?.display_name) addressEl.value = data.display_name;
      } catch {}
    }

    marker.on('dragend', () => {
      const { lat, lng } = marker.getLatLng();
      setPos(lat, lng, false);
      reverseGeocode(lat, lng);
    });

    map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      setPos(lat, lng);
      reverseGeocode(lat, lng);
    });

    const btn = document.getElementById(useMyLocationBtnId);
    if (btn) {
      btn.addEventListener('click', () => {
        if (!navigator.geolocation) return Toast?.error?.('المتصفح لا يدعم تحديد الموقع');
        navigator.geolocation.getCurrentPosition((pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setPos(lat, lng);
          reverseGeocode(lat, lng);
          Toast?.success?.('تم تحديد موقعك');
        }, () => Toast?.error?.('تعذر تحديد الموقع'));
      });
    }

    // initialize position fields
    setPos(cairo[0], cairo[1], false);
  }

  window.initMap = initMap;
})();
