/* Admin dashboard interactions */
(function(){
  function qs(sel){ return document.querySelector(sel); }
  function qa(sel){ return Array.from(document.querySelectorAll(sel)); }

  let page = 1;
  const pageSize = 20;
  let lastFilter = {};

  async function init(){
    try {
      const me = await API.adminMe().catch(() => null);
      if (!me) {
        location.href = '/admin/login.html';
        return;
      }
      qs('#meBox').textContent = me.email + ' (' + me.role + ')';
    } catch {}
    bindControls();
    await reload();
  }

  function bindControls(){
    qs('#logoutBtn').addEventListener('click', async () => {
      await API.adminLogout().catch(()=>{});
      location.href = '/admin/login.html';
    });

    qs('#filterBtn').addEventListener('click', async () => {
      page = 1;
      await reload();
    });

    qs('#prevBtn').addEventListener('click', async () => {
      if (page > 1) { page--; await reload(); }
    });
    qs('#nextBtn').addEventListener('click', async () => {
      page++; await reload();
    });

    qs('#exportBtn').addEventListener('click', () => {
      const params = buildFilter();
      const q = new URLSearchParams(params).toString();
      window.open('/admin/export.csv' + (q ? '?' + q : ''), '_blank');
    });
  }

  function buildFilter(){
    return {
      q: qs('#q').value.trim() || undefined,
      type: qs('#type').value || undefined,
      status: qs('#status').value || undefined,
      gov: qs('#gov').value.trim() || undefined,
      city: qs('#city').value.trim() || undefined,
      page,
      pageSize
    };
  }

  async function reload(){
    try {
      const filter = buildFilter();
      lastFilter = filter;
      const data = await API.adminList(filter);
      renderTable(data.items || []);
      qs('#pagerInfo').textContent = `صفحة ${data.page} من ${data.pages} — إجمالي ${data.total}`;
      // update KPIs
      updateKpis(data.items || []);
    } catch(e) {
      Toast.error(e.message || 'تعذر تحميل البيانات');
    }
  }

  function updateKpis(items){
    // Simple counts from current page (for demo). For production, add KPIs API if needed.
    const cnt = { pending:0, in_review:0, approved:0, rejected:0 };
    items.forEach(it => { cnt[it.status] = (cnt[it.status]||0) + 1; });
    qs('#kpiPending').textContent = cnt.pending;
    qs('#kpiReview').textContent = cnt.in_review;
    qs('#kpiApproved').textContent = cnt.approved;
    qs('#kpiRejected').textContent = cnt.rejected;
  }

  function renderTable(items){
    const tbody = qs('#appsTable tbody');
    tbody.innerHTML = '';
    items.forEach((a, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${idx + 1 + (page-1)*pageSize}</td>
        <td>${typeLabel(a.type)}</td>
        <td>${escapeHtml(a.storeName)}</td>
        <td>${escapeHtml(a.email)}</td>
        <td>${escapeHtml(a.phone)}</td>
        <td>${escapeHtml(a.gov)} / ${escapeHtml(a.city)}</td>
        <td><span class="badge status ${a.status}">${statusLabel(a.status)}</span></td>
        <td>${new Date(a.createdAt).toLocaleString('ar-EG')}</td>
        <td class="actions">
          <button class="btn btn-outline" data-view="${a.id}">عرض</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // bind view
    qa('[data-view]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.getAttribute('data-view');
        const detail = await API.adminGet(id);
        renderDetails(detail);
      });
    });
  }

  function renderDetails(app){
    const sec = qs('#details');
    const body = qs('#detailBody');
    sec.hidden = false;
    body.innerHTML = `
      <div><b>المتجر:</b> ${escapeHtml(app.storeName)}</div>
      <div><b>النوع:</b> ${typeLabel(app.type)}</div>
      <div><b>البريد:</b> ${escapeHtml(app.email)}</div>
      <div><b>الهاتف:</b> ${escapeHtml(app.phone)}</div>
      <div><b>المحافظة/المدينة:</b> ${escapeHtml(app.gov)} / ${escapeHtml(app.city)}</div>
      <div><b>العنوان:</b> ${escapeHtml(app.addressText)}</div>
      <div><b>الموقع:</b> <a href="https://maps.google.com/?q=${app.lat},${app.lng}" target="_blank">عرض على الخريطة</a></div>
      <div><b>الحالة الحالية:</b> ${statusLabel(app.status)}</div>
      <div class="grid">
        <div class="field">
          <label>تغيير الحالة</label>
          <select id="newStatus">
            <option value="">اختر الحالة</option>
            <option value="in_review">قيد المراجعة</option>
            <option value="approved">تمت الموافقة</option>
            <option value="rejected">مرفوض</option>
          </select>
        </div>
        <div class="field">
          <label>ملاحظة</label>
          <input id="reviewNote" class="note" type="text" placeholder="سبب/ملاحظة" />
        </div>
        <div class="field">
          <label>المرفقات</label>
          <div class="inline">
            ${app.documents.map(d => `<a class="badge" href="${d.fileUrl}" target="_blank">${escapeHtml(d.kind)} (${escapeHtml(d.mime)})</a>`).join(' ')}
          </div>
        </div>
        <div class="field">
          <button id="applyChange" class="btn">حفظ التغييرات</button>
        </div>
      </div>
    `;

    qs('#applyChange').addEventListener('click', async () => {
      try {
        const status = qs('#newStatus').value || undefined;
        const reviewNote = qs('#reviewNote').value.trim() || undefined;
        if (!status && !reviewNote) return Toast.error('اختر حالة أو اكتب ملاحظة');
        await API.adminPatch(app.id, { status, reviewNote });
        Toast.success('تم التحديث');
        await reload();
      } catch(e) {
        Toast.error(e.message || 'تعذر حفظ التغييرات');
      }
    });
  }

  function typeLabel(t){
    return t === 'pharmacy' ? 'صيدلية' : t === 'supermarket' ? 'سوبر ماركت' : 'مطعم';
  }
  function statusLabel(s){
    return s === 'pending' ? 'قيد الانتظار' :
           s === 'in_review' ? 'قيد المراجعة' :
           s === 'approved' ? 'تمت الموافقة' : 'مرفوض';
  }
  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'<','>':'>','"':'"',"'":'&#39;'}[m]));
  }

  document.addEventListener('DOMContentLoaded', init);
})();
