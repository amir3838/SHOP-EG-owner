/* Registration wizard logic (Vanilla JS, RTL) */
(function(){
  const state = {
    step: 1,
    type: null,
    requestId: null,
    verificationOk: false,
    docs: {}, // kind -> {file, sha256, mime, size, publicUrl}
  };

  function qs(sel){ return document.querySelector(sel); }
  function qa(sel){ return Array.from(document.querySelectorAll(sel)); }

  function showStep(n){
    state.step = n;
    qa('.step').forEach(el => {
      const s = Number(el.dataset.step);
      el.classList.toggle('active', s === n);
      el.classList.toggle('completed', s < n);
    });
    qa('.step-pane').forEach(el => el.hidden = Number(el.dataset.step) !== n);

    // Restore stored verification requestId if user already sent verification earlier
    if (n === 4 && !state.requestId) {
      const emailEl = qs('#email');
      const emailVal = emailEl ? emailEl.value.trim() : '';
      if (emailVal) {
        try {
          const saved = localStorage.getItem('verify:' + emailVal);
          if (saved) state.requestId = saved;
        } catch {}
      }
    }
  }

  function initSteps(){
    qa('[data-next]').forEach(btn => btn.addEventListener('click', () => {
      if (state.step === 1) {
        const type = (document.querySelector('input[name="type"]:checked') || {}).value;
        if (!type) return Toast.error('الرجاء اختيار النشاط');
        state.type = type;
        renderActivityDocs();
        showStep(2);
      } else if (state.step === 2) {
        if (!validateStep2()) return;
        showStep(3);
        setTimeout(() => {
          if (window.initMap) window.initMap({ mapId:'map', latInputId:'lat', lngInputId:'lng', addressInputId:'addressText', useMyLocationBtnId:'useMyLocation' });
        }, 50);
      } else if (state.step === 3) {
        if (!validateStep3()) return;
        showStep(4);
      }
    }));
    qa('[data-prev]').forEach(btn => btn.addEventListener('click', () => {
      if (state.step > 1) showStep(state.step - 1);
    }));
  }

  function validateStep2(){
    const storeName = qs('#storeName').value.trim();
    const email = qs('#email').value.trim();
    const phone = qs('#phone').value.trim();
    const gov = qs('#gov').value.trim();
    const city = qs('#city').value.trim();
    const addressText = qs('#addressText').value.trim();
    if (!storeName || !email || !phone || !gov || !city || !addressText) {
      Toast.error('يرجى تعبئة جميع الحقول');
      return false;
    }
    const e164 = /^\+[1-9]\d{7,14}$/;
    if (!e164.test(phone)) {
      Toast.error('الهاتف يجب أن يكون بصيغة E.164 مثل +201234567890');
      return false;
    }
    // Client-side Qalyubia rule reminder; server enforces strictly
    if (gov === 'القليوبية') {
      const allowed = ['مدينة العبور','الخانكة','الخصوص'];
      if (!allowed.includes(city)) {
        Toast.error('القليوبية: المدن المسموحة (العبور/الخانكة/الخصوص)');
        return false;
      }
    }
    return true;
  }

  function validateStep3(){
    const lat = qs('#lat').value.trim();
    const lng = qs('#lng').value.trim();
    if (!lat || !lng) {
      Toast.error('يرجى تحديد الموقع على الخريطة');
      return false;
    }
    const sign = state.docs['sign_photo'];
    if (!sign || !sign.publicUrl) {
      Toast.error('صورة يافطة المتجر إلزامية');
      return false;
    }
    if (state.type === 'pharmacy') {
      if (!state.docs['ph_license'] || !state.docs['ph_cr'] || !state.docs['ph_id']) {
        Toast.error('صيدلية: مطلوب رخصة صيدلية + سجل تجاري + بطاقة مسؤول');
        return false;
      }
    } else if (state.type === 'supermarket' || state.type === 'restaurant') {
      if (!state.docs['sm_id']) {
        Toast.error('سوبر ماركت / مطعم: بطاقة مسؤول إلزامية');
        return false;
      }
    }
    if (state.type === 'restaurant') {
      const tags = getSelectedKitchenTags();
      if (tags.length === 0) {
        Toast.error('مطعم: يجب اختيار نوع/أنواع المطبخ');
        return false;
      }
    }
    return true;
  }

  function renderActivityDocs(){
    const wrap = qs('#activityDocs');
    wrap.innerHTML = '';
    const fields = [];
    // Common sign photo already exists as #signPhoto
    if (state.type === 'pharmacy') {
      fields.push({ id:'ph_license', label:'رخصة صيدلية (صورة/PDF)', accept:'image/jpeg,image/png,application/pdf' });
      fields.push({ id:'ph_cr', label:'سجل تجاري (صورة/PDF)', accept:'image/jpeg,image/png,application/pdf' });
      fields.push({ id:'ph_id', label:'بطاقة مسؤول (صورة)', accept:'image/jpeg,image/png' });
    } else if (state.type === 'supermarket' || state.type === 'restaurant') {
      fields.push({ id:'sm_id', label:'بطاقة مسؤول (صورة) - إلزامية', accept:'image/jpeg,image/png' });
      fields.push({ id:'sm_cr', label:'سجل تجاري (اختياري)', accept:'image/jpeg,image/png,application/pdf', optional:true });
      fields.push({ id:'sm_tax', label:'بطاقة ضريبية (اختياري)', accept:'image/jpeg,image/png,application/pdf', optional:true });
      if (state.type === 'restaurant') {
        // Build kitchen checkboxes without nested template strings
        const kitchenWrap = document.createElement('div');
        kitchenWrap.className = 'field';
        const label = document.createElement('label');
        label.textContent = 'أنواع المطبخ (مطعم)';
        const inline = document.createElement('div');
        inline.className = 'inline';
        const kitchens = ['فطار مصري','سوري','شرقي','مشويات','بحري','فاست فود','حلويات','كافيه'];
        kitchens.forEach(k => {
          const l = document.createElement('label');
          l.className = 'badge';
          const cb = document.createElement('input');
          cb.type = 'checkbox';
          cb.value = k;
          l.appendChild(cb);
          l.appendChild(document.createTextNode(' ' + k));
          inline.appendChild(l);
        });
        kitchenWrap.appendChild(label);
        kitchenWrap.appendChild(inline);
        wrap.appendChild(kitchenWrap);
      }
    }
    fields.forEach(f => {
      const el = document.createElement('div');
      el.className = 'field';
      el.innerHTML = `
        <label>${f.label}${f.optional ? ' (اختياري)' : ''}</label>
        <input type="file" id="${f.id}" accept="${f.accept}" ${f.optional ? '' : 'required'} />
      `;
      wrap.appendChild(el);
    });
  }

  function getSelectedKitchenTags(){
    return qa('#activityDocs input[type="checkbox"]:checked').map(i => i.value);
  }

  function bindGovCity(){
    const gov = qs('#gov');
    const city = qs('#city');
    if (window.populateGovCity) window.populateGovCity(gov, city);
  }

  // Simple client-side SHA-256
  async function sha256Hex(file){
    const buf = await file.arrayBuffer();
    const digest = await crypto.subtle.digest('SHA-256', buf);
    const arr = Array.from(new Uint8Array(digest));
    return arr.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  async function compressImageIfNeeded(file){
    // Only compress if > 500KB and image
    if (!/^image\/(png|jpeg)$/.test(file.type) || file.size <= 500*1024) return file;
    return new Promise(resolve => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, Math.sqrt((1200*1200) / (img.width * img.height)));
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          resolve(new File([blob], file.name, { type: file.type }));
        }, file.type, 0.82);
      };
      img.src = URL.createObjectURL(file);
    });
  }

  async function handleUpload(inputEl, kind){
    const file = inputEl.files && inputEl.files[0];
    if (!file) return;

    // Validate MIME/size
    const allowed = ['image/jpeg','image/png','application/pdf'];
    if (!allowed.includes(file.type)) {
      return Toast.error('صيغة الملف غير مدعومة');
    }
    if (file.size > 10 * 1024 * 1024) {
      return Toast.error('الحد الأقصى لحجم الملف 10MB');
    }

    const sourceFile = await compressImageIfNeeded(file);
    const sha = await sha256Hex(sourceFile);

    // Ask backend for presigned POST
    const sign = await API.signUpload(sourceFile.name, sourceFile.type, kind);
    // Upload directly to storage
    await API.uploadPresigned({ url: sign.url, fields: sign.fields, file: sourceFile });
    // Save reference
    state.docs[kind] = {
      file: sourceFile,
      sha256: sha,
      mime: sourceFile.type,
      size: sourceFile.size,
      publicUrl: sign.publicUrl
    };
    Toast.success('تم رفع الملف بنجاح');
  }

  function bindUploads(){
    const map = {
      signPhoto: 'sign_photo',
      ph_license: 'ph_license',
      ph_cr: 'ph_cr',
      ph_id: 'ph_id',
      sm_id: 'sm_id',
      sm_cr: 'sm_cr',
      sm_tax: 'sm_tax'
    };
    Object.entries(map).forEach(([id, kind]) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', () => handleUpload(el, kind));
      }
    });
    // Also bind dynamically created inputs (activityDocs)
    const observer = new MutationObserver(() => {
      Object.entries(map).forEach(([id, kind]) => {
        const el2 = document.getElementById(id);
        if (el2 && !el2.dataset._bound) {
          el2.dataset._bound = '1';
          el2.addEventListener('change', () => handleUpload(el2, kind));
        }
      });
    });
    observer.observe(document.getElementById('activityDocs'), { childList: true, subtree: true });
    // bind initial sign photo
    const signEl = document.getElementById('signPhoto');
    if (signEl) signEl.addEventListener('change', () => handleUpload(signEl, 'sign_photo'));
  }

  function bindVerifyAndSubmit(){
    const sendBtn = qs('#sendVerifyBtn');
    const submitBtn = qs('#submitAppBtn');

    sendBtn.addEventListener('click', async () => {
      try {
        const emailInput = qs('#email');
        const email = emailInput.value.trim();
        const r = await API.sendVerification(email);
        state.requestId = r.requestId;

        // Persist requestId for this email to survive refresh/back navigation
        try { localStorage.setItem('verify:' + email, state.requestId); } catch {}

        Toast.success('تم إرسال رابط التحقق إلى بريدك');
        // افتح صفحة التحقق بالـ requestId فقط
        const url = new URL(window.location.origin + '/verify.html');
        url.searchParams.set('requestId', state.requestId);
        window.open(url.toString(), '_blank');
      } catch (e) {
        Toast.error(e.message || 'فشل إرسال رابط التحقق');
      }
    });

    submitBtn.addEventListener('click', async () => {
      try {
        if (!state.requestId) {
          return Toast.error('الرجاء إرسال رابط التحقق أولاً وإتمام تأكيد البريد');
        }

        const payload = buildApplicationPayload();
        const res = await API.createApplication(payload);
        Toast.success('تم إنشاء الطلب بنجاح');

        // Clean persisted verification for this email
        try { localStorage.removeItem('verify:' + payload.email); } catch {}

        // Redirect to success page with id
        const url = new URL(window.location.origin + '/success.html');
        url.searchParams.set('id', res.id);
        window.location.href = url.toString();
      } catch (e) {
        Toast.error(e.message || 'تعذر إنشاء الطلب');
      }
    });
  }

  function buildApplicationPayload(){
    const storeName = qs('#storeName').value.trim();
    const email = qs('#email').value.trim();
    const phone = qs('#phone').value.trim();
    const gov = qs('#gov').value.trim();
    const city = qs('#city').value.trim();
    const addressText = qs('#addressText').value.trim();
    const lat = Number(qs('#lat').value.trim());
    const lng = Number(qs('#lng').value.trim());
    const documents = Object.entries(state.docs).map(([kind, d]) => ({
      kind, fileUrl: d.publicUrl, mime: d.mime, size: d.size, sha256: d.sha256
    }));

    const payload = {
      type: state.type,
      storeName, email, phone, gov, city, addressText, lat, lng,
      verificationRequestId: state.requestId,
      documents
    };

    if (state.type === 'restaurant') {
      payload.kitchenTypes = getSelectedKitchenTags();
    }
    return payload;
  }

  document.addEventListener('DOMContentLoaded', () => {
    initSteps();
    bindGovCity();
    bindUploads();
    bindVerifyAndSubmit();
    showStep(1);
  });
})();
