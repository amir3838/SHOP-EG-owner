/**
 * Simple toast system (RTL)
 */
const Toast = (() => {
  let root;
  function ensureRoot() {
    if (!root) {
      root = document.createElement('div');
      root.className = 'toast';
      document.body.appendChild(root);
    }
  }
  function show(message, type = 'success', timeout = 3500) {
    ensureRoot();
    const item = document.createElement('div');
    item.className = `item ${type}`;
    item.textContent = message;
    root.appendChild(item);
    const id = setTimeout(() => {
      try { root.removeChild(item); } catch {}
    }, timeout);
    item.addEventListener('click', () => {
      clearTimeout(id);
      try { root.removeChild(item); } catch {}
    });
  }
  return { show, success: (m,t)=>show(m,'success',t), error: (m,t)=>show(m,'error',t) };
})();

window.Toast = Toast;
