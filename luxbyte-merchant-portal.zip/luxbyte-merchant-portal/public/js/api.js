/* Simple API layer for the portal */
const API = (() => {
  const base = '';

  async function request(path, body) {
    const res = await fetch(base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body ?? {})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data?.error || 'Request failed');
    }
    return data;
  }

  async function get(path) {
    const res = await fetch(base + path, { credentials: 'include' });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data?.error || 'Request failed');
    }
    return data;
  }

  async function patch(path, body) {
    const res = await fetch(base + path, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(body ?? {})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data?.error || 'Request failed');
    }
    return data;
  }

  // Verify
  const sendVerification = (email) => request('/verify/send', { email });
  const confirmVerification = (requestId, token) => request('/verify/confirm', { requestId, token });

  // Upload signing (S3 presigned POST)
  async function signUpload(fileName, mime, scope) {
    return request('/uploads/sign', { fileName, mime, scope });
  }

  // Upload to S3 using the presigned POST url/fields
  async function uploadPresigned({ url, fields, file }) {
    const form = new FormData();
    Object.entries(fields).forEach(([k, v]) => form.append(k, v));
    form.append('file', file);
    const res = await fetch(url, { method: 'POST', body: form });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error('Upload failed: ' + text.slice(0, 200));
    }
    return true;
  }

  // Applications
  const createApplication = (payload) => request('/applications', payload);
  const getApplication = (id) => get('/applications/' + encodeURIComponent(id));
  const listApplications = (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return get('/applications' + (q ? '?' + q : ''));
  };

  // Admin
  const adminLogin = (email, password) => request('/admin/login', { email, password });
  const adminLogout = () => request('/admin/logout', {});
  const adminMe = () => get('/admin/me');
  const adminList = (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return get('/admin/applications' + (q ? '?' + q : ''));
  };
  const adminGet = (id) => get('/admin/applications/' + encodeURIComponent(id));
  const adminPatch = (id, data) => patch('/applications/' + encodeURIComponent(id), data);

  return {
    sendVerification,
    confirmVerification,
    signUpload,
    uploadPresigned,
    createApplication,
    getApplication,
    listApplications,
    adminLogin,
    adminLogout,
    adminMe,
    adminList,
    adminGet,
    adminPatch
  };
})();

window.API = API;
