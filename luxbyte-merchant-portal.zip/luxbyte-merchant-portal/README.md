# 🚀 Luxbyte Merchant Portal - منصة توكيد التجار

<div align="center">

![Luxbyte Logo](public/assets/logo.png)

**بوابة ويب عصرية لتسجيل وتوكيد التجار**

[![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Live-brightgreen)](https://your-username.github.io/luxbyte-merchant-portal)
[![Node.js](https://img.shields.io/badge/Node.js-20+-green)](https://nodejs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-blue)](https://www.typescriptlang.org/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

</div>

## ✨ المميزات الجديدة

### 🎨 واجهة مستخدم عصرية
- **تصميم ثلاثي الأبعاد** مع أزرار تفاعلية
- **أنيميشن متقدم** مع تأثيرات بصرية رائعة
- **ألوان عصرية**: أحمر، أبيض، أسود، ذهبي
- **تصميم متجاوب** يعمل على جميع الأجهزة
- **واجهة عربية RTL** بخط Cairo الجميل

### 🚀 تقنيات حديثة
- **شاشة تحميل** مع أنيميشن دوار
- **تأثير الكتابة** للنصوص
- **عداد متحرك** للإحصائيات
- **عناصر طافية** مع حركة طبيعية
- **تدرجات لونية** وظلال ثلاثية الأبعاد

## 🛠️ التقنيات المستخدمة

### Frontend
- **HTML5** مع دعم RTL
- **CSS3** مع Flexbox & Grid
- **JavaScript ES6+** مع أنيميشن متقدم
- **Google Fonts** (Cairo)

### Backend
- **Node.js 20+**
- **TypeScript**
- **Express.js**
- **Prisma ORM**
- **PostgreSQL (Supabase)**

### الاستضافة والنشر
- **GitHub Pages** للواجهة الأمامية
- **GitHub Actions** للنشر التلقائي
- **Vercel/Railway** للخادم (اختياري)

## 🚀 التشغيل السريع

### 1. استنساخ المشروع
```bash
git clone https://github.com/your-username/luxbyte-merchant-portal.git
cd luxbyte-merchant-portal
```

### 2. تثبيت المتطلبات
```bash
npm install
```

### 3. إعداد البيئة
انسخ `.env.example` إلى `.env` وأضف القيم المطلوبة:
```bash
cp .env.example .env
```

### 4. تشغيل الخادم
```bash
# وضع التطوير
npm run dev

# وضع الإنتاج
npm run build
npm start
```

## 🎨 معاينة الواجهة

### الصفحة الرئيسية
- شاشة تحميل مع أنيميشن الشعار
- عنوان متحرك بتأثير الظهور التدريجي
- نص بتأثير الكتابة: "هنكبر مع بعض"
- أيقونات المميزات مع أنيميشن القفز
- أزرار ثلاثية الأبعاد مع تأثيرات الضوء
- عداد الإحصائيات المتحرك
- عناصر طافية في الخلفية

### الألوان والتصميم
```css
:root {
  --brand-red: #E01E26;
  --brand-gold: #FFD700;
  --brand-black: #1A1A1A;
  --brand-white: #FFFFFF;
}
```

## 📱 التصميم المتجاوب

الواجهة تعمل بشكل مثالي على:
- 🖥️ أجهزة الكمبيوتر
- 📱 الهواتف الذكية
- 📟 الأجهزة اللوحية

## 🌐 النشر على GitHub Pages

### 1. إنشاء مستودع GitHub
```bash
git remote add origin https://github.com/your-username/luxbyte-merchant-portal.git
git branch -M main
git push -u origin main
```

### 2. تفعيل GitHub Pages
1. اذهب إلى إعدادات المستودع
2. اختر "Pages" من القائمة الجانبية
3. اختر "GitHub Actions" كمصدر
4. سيتم النشر تلقائياً عند كل push

### 3. إضافة المتغيرات السرية
في إعدادات المستودع > Secrets and variables > Actions:
```
DATABASE_URL=your_database_url
DIRECT_URL=your_direct_url
S3_ENDPOINT=your_s3_endpoint
S3_ACCESS_KEY_ID=your_access_key
S3_SECRET_ACCESS_KEY=your_secret_key
JWT_SECRET=your_jwt_secret
CSRF_SECRET=your_csrf_secret
CORS_ORIGINS=https://your-username.github.io
```

## 🎯 المميزات التقنية

### أنيميشن CSS
- **Keyframes** للحركات المعقدة
- **Transform** للتحويلات ثلاثية الأبعاد
- **Transition** للانتقالات السلسة
- **Animation** للحركات المتكررة

### JavaScript التفاعلي
- **تأثير الكتابة** للنصوص
- **عداد متحرك** للأرقام
- **أنيميشن التحميل** المتقدم
- **تفاعل الأزرار** مع التأثيرات

### تحسين الأداء
- **تحميل الخطوط** المُحسن
- **ضغط الصور** التلقائي
- **تأخير التحميل** للعناصر
- **تحسين CSS** للسرعة

## 📊 الإحصائيات

- ✅ **1000+** تاجر مسجل
- ✅ **50+** مدينة مغطاة
- ✅ **99%** معدل نجاح
- ✅ **24/7** دعم فني

## 🤝 المساهمة

نرحب بمساهماتكم! يرجى:

1. Fork المشروع
2. إنشاء branch جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى Branch (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## 📞 التواصل

- **الهاتف**: +201148709609
- **العنوان**: 42 شارع البحر، شيراتون، القاهرة – الدور الخامس
- **البريد**: admin@luxbyte.com

## 📄 الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف [LICENSE](LICENSE) للتفاصيل.

---

<div align="center">

**© 2024 Luxbyte LLC - جميع الحقوق محفوظة**

*"هنكبر مع بعض" 🚀*

</div>
