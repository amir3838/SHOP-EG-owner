// Global variables
let currentBusinessType = '';
let map = null;
let marker = null;
let applicationData = {};
let otpRequestId = '';

// City data structure
const citiesByGov = {
    "القاهرة": [
        "القاهرة الجديدة/التجمع الخامس",
        "مدينة نصر",
        "مصر الجديدة/هليوبوليس",
        "الشروق",
        "بدر",
        "الرحاب",
        "مدينتي",
        "المعادى",
        "زهراء المعادي",
        "المقطم",
        "حلوان",
        "15 مايو",
        "حدائق حلوان",
        "النزهة",
        "الزيتون",
        "عين شمس",
        "المطرية",
        "المرج",
        "السلام",
        "العباسية",
        "حدائق القبة",
        "شبرا",
        "الشرابية",
        "الوايلي",
        "روض الفرج",
        "وسط البلد/القاهرة الخديوية",
        "الزمالك",
        "السيدة زينب",
        "دار السلام",
        "البساتين",
        "التبين"
    ],
    "الجيزة": [
        "الجيزة (المدينة)",
        "الدقي",
        "المهندسين",
        "العجوزة",
        "إمبابة",
        "الوراق",
        "كيت كات",
        "بولاق الدكرور",
        "ناهيا",
        "بين السرايات",
        "الهرم",
        "فيصل",
        "حدائق الأهرام",
        "ساقية مكي",
        "المنيب",
        "6 أكتوبر",
        "الشيخ زايد",
        "البدرشين",
        "الحوامدية",
        "العياط",
        "أطفيح",
        "الصف",
        "منشأة القناطر",
        "كرداسة",
        "أوسيم"
    ],
    "القليوبية": [
        "مدينة العبور",
        "الخانكة",
        "الخصوص"
    ]
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    initializeMap();
});

// Initialize event listeners
function initializeEventListeners() {
    // Start registration button
    document.getElementById('start-registration').addEventListener('click', function() {
        showScreen('business-type-screen');
    });

    // Business type selection
    const businessCards = document.querySelectorAll('.business-card');
    businessCards.forEach(card => {
        card.addEventListener('click', function() {
            currentBusinessType = this.dataset.type;
            showScreen('registration-screen');
            addTypeSpecificFields();
        });
    });

    // Governorate change
    document.getElementById('governorate').addEventListener('change', updateCities);

    // Use my location button
    document.getElementById('use-my-location').addEventListener('click', getCurrentLocation);

    // Image preview
    document.getElementById('store-sign').addEventListener('change', previewImage);

    // Registration form submission
    document.getElementById('registration-form').addEventListener('submit', handleRegistrationSubmit);

    // OTP form submission
    document.getElementById('otp-form').addEventListener('submit', handleOtpSubmit);
}

// Screen management
function showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    
    // Show the requested screen
    document.getElementById(screenId).classList.add('active');
    
    // Additional setup for specific screens
    if (screenId === 'registration-screen') {
        updateCities();
        initializeMap();
    }
}

// Update cities based on selected governorate
function updateCities() {
    const governorateSelect = document.getElementById('governorate');
    const citySelect = document.getElementById('city');
    const selectedGov = governorateSelect.value;
    
    citySelect.innerHTML = '<option value="">اختر المدينة/الحي</option>';
    citySelect.disabled = !selectedGov;
    
    if (selectedGov && citiesByGov[selectedGov]) {
        citiesByGov[selectedGov].forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            citySelect.appendChild(option);
        });
    }
}

// Initialize Leaflet map
function initializeMap() {
    const mapContainer = document.getElementById('map-container');
    if (!mapContainer) return;
    
    // Clear existing map
    if (map) {
        map.remove();
    }
    
    // Create new map centered on Egypt
    map = L.map('map-container').setView([30.0444, 31.2357], 10);
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Add click event to place marker
    map.on('click', function(e) {
        if (marker) {
            map.removeLayer(marker);
        }
        marker = L.marker(e.latlng).addTo(map);
        document.getElementById('latitude').value = e.latlng.lat;
        document.getElementById('longitude').value = e.latlng.lng;
        
        // Reverse geocoding (simplified)
        reverseGeocode(e.latlng.lat, e.latlng.lng);
    });
}

// Get current location
function getCurrentLocation() {
    if (!navigator.geolocation) {
        showToast('Geolocation is not supported by this browser', 'error');
        return;
    }
    
    showToast('جاري الحصول على الموقع...', 'info');
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // Set map view to current location
            map.setView([lat, lng], 15);
            
            // Add marker
            if (marker) {
                map.removeLayer(marker);
            }
            marker = L.marker([lat, lng]).addTo(map);
            
            // Set hidden inputs
            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;
            
            // Reverse geocoding
            reverseGeocode(lat, lng);
            
            showToast('تم تحديد موقعك بنجاح', 'success');
        },
        function(error) {
            showToast('فشل في الحصول على الموقع', 'error');
            console.error('Geolocation error:', error);
        }
    );
}

// Simplified reverse geocoding
function reverseGeocode(lat, lng) {
    // In a real implementation, you would use a geocoding service
    // For now, we'll just show coordinates
    const addressTextarea = document.getElementById('address');
    if (addressTextarea.value.trim() === '') {
        addressTextarea.value = `الموقع: ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    }
}

// Image preview
function previewImage(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('image-preview');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        };
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = '';
    }
}

// Add type-specific fields
function addTypeSpecificFields() {
    const container = document.getElementById('type-specific-fields');
    container.innerHTML = '';
    
    switch (currentBusinessType) {
        case 'pharmacy':
            container.innerHTML = `
                <div class="form-group">
                    <label for="pharmacy-license">رخصة الصيدلية (صورة/PDF) *</label>
                    <input type="file" id="pharmacy-license" name="pharmacyLicense" accept="image/*,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="commercial-register">السجل التجاري (صورة/PDF) *</label>
                    <input type="file" id="commercial-register" name="commercialRegister" accept="image/*,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="manager-id">بطاقة المسؤول (صورة) *</label>
                    <input type="file" id="manager-id" name="managerId" accept="image/*" required>
                </div>
            `;
            break;
            
        case 'supermarket':
            container.innerHTML = `
                <div class="form-group">
                    <label for="manager-id">بطاقة المسؤول (صورة) *</label>
                    <input type="file" id="manager-id" name="managerId" accept="image/*" required>
                </div>
                <div class="form-group">
                    <label for="commercial-register">السجل التجاري (صورة/PDF)</label>
                    <input type="file" id="commercial-register" name="commercialRegister" accept="image/*,.pdf">
                </div>
                <div class="form-group">
                    <label for="tax-card">البطاقة الضريبية (صورة/PDF)</label>
                    <input type="file" id="tax-card" name="taxCard" accept="image/*,.pdf">
                </div>
            `;
            break;
            
        case 'restaurant':
            const cuisines = [
                'فطار مصري', 'سوري', 'شرقي', 'مشويات', 'بحري', 
                'فاست فود', 'حلويات', 'كافيه', 'إيطالي', 'صيني'
            ];
            
            let cuisineOptions = cuisines.map(cuisine => 
                `<option value="${cuisine}">${cuisine}</option>`
            ).join('');
            
            container.innerHTML = `
                <div class="form-group">
                    <label for="manager-id">بطاقة المسؤول (صورة) *</label>
                    <input type="file" id="manager-id" name="managerId" accept="image/*" required>
                </div>
                <div class="form-group">
                    <label for="commercial-register">السجل التجاري (صورة/PDF)</label>
                    <input type="file" id="commercial-register" name="commercialRegister" accept="image/*,.pdf">
                </div>
                <div class="form-group">
                    <label for="tax-card">البطاقة الضريبية (صورة/PDF)</label>
                    <input type="file" id="tax-card" name="taxCard" accept="image/*,.pdf">
                </div>
                <div class="form-group">
                    <label for="cuisines">أنواع المطبخ (اختيار متعدد)</label>
                    <select id="cuisines" name="cuisines" multiple style="height: 120px;">
                        ${cuisineOptions}
                    </select>
                    <small>اضغط Ctrl/Command للاختيار المتعدد</small>
                </div>
            `;
            break;
    }
}

// Handle registration form submission
async function handleRegistrationSubmit(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    // Basic validation
    if (!validateForm(data)) {
        return;
    }
    
    try {
        showToast('جاري إرسال البيانات...', 'info');
        
        // Upload files and get URLs
        const fileUrls = await uploadFiles(formData);
        
        // Prepare application data
        applicationData = {
            type: currentBusinessType,
            storeName: data.storeName,
            email: data.email,
            phone: data.phone,
            governorate: data.governorate,
            city: data.city,
            addressText: data.address,
            latitude: parseFloat(data.latitude),
            longitude: parseFloat(data.longitude),
            documents: fileUrls,
            cuisines: data.cuisines ? Array.isArray(data.cuisines) ? data.cuisines : [data.cuisines] : []
        };
        
        // Send OTP
        const response = await fetch('http://localhost:3000/api/otp/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: data.email })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            otpRequestId = result.requestId;
            showScreen('otp-screen');
            showToast('تم إرسال رمز التحقق إلى بريدك الإلكتروني', 'success');
        } else {
            showToast(result.message || 'فشل في إرسال رمز التحقق', 'error');
        }
        
    } catch (error) {
        console.error('Registration error:', error);
        showToast('حدث خطأ أثناء التسجيل', 'error');
    }
}

// Validate form data
function validateForm(data) {
    // Check required fields
    const requiredFields = ['storeName', 'email', 'phone', 'governorate', 'city', 'address'];
    for (const field of requiredFields) {
        if (!data[field] || data[field].trim() === '') {
            showToast(`يرجى ملء حقل ${field}`, 'error');
            return false;
        }
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
        showToast('البريد الإلكتروني غير صحيح', 'error');
        return false;
    }
    
    // Validate phone format (E.164)
    const phoneRegex = /^\+[1-9]\d{1,14}$/;
    if (!phoneRegex.test(data.phone)) {
        showToast('رقم الهاتف يجب أن يكون بصيغة E.164', 'error');
        return false;
    }
    
    // Validate Qalyubia cities
    if (data.governorate === 'القليوبية') {
        const allowedCities = ['مدينة العبور', 'الخانكة', 'الخصوص'];
        if (!allowedCities.includes(data.city)) {
            showToast('المدينة المختارة غير مسموح بها في محافظة القليوبية', 'error');
            return false;
        }
    }
    
    return true;
}

// Upload files and return URLs
async function uploadFiles(formData) {
    const files = {};
    const fileFields = ['storeSign', 'pharmacyLicense', 'commercialRegister', 'managerId', 'taxCard'];
    
    for (const field of fileFields) {
        const file = formData.get(field);
        if (file && file.size > 0) {
            // In a real implementation, you would get a presigned URL from the server
            // and upload the file to S3-compatible storage
            // For now, we'll simulate the upload and return placeholder URLs
            files[field] = {
                url: `https://example.com/uploads/${Date.now()}_${file.name}`,
                mime: file.type,
                size: file.size
            };
        }
    }
    
    return files;
}

// Handle OTP submission
async function handleOtpSubmit(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const otpCode = formData.get('otpCode');
    
    if (!otpCode || otpCode.length !== 6) {
        showToast('يرجى إدخال رمز التحقق المكون من 6 أرقام', 'error');
        return;
    }
    
    try {
        showToast('جاري التحقق...', 'info');
        
        const response = await fetch('http://localhost:3000/api/otp/verify', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                requestId: otpRequestId,
                code: otpCode
            })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            // OTP verified, submit application
            await submitApplication();
        } else {
            showToast(result.message || 'رمز التحقق غير صحيح', 'error');
        }
        
    } catch (error) {
        console.error('OTP verification error:', error);
        showToast('حدث خطأ أثناء التحقق', 'error');
    }
}

// Submit application after OTP verification
async function submitApplication() {
    try {
        showToast('جاري إرسال الطلب...', 'info');
        
        const response = await fetch('http://localhost:3000/api/applications', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(applicationData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            document.getElementById('application-id').textContent = result.applicationId;
            showScreen('success-screen');
            showToast('تم تقديم الطلب بنجاح', 'success');
        } else {
            showToast(result.message || 'فشل في تقديم الطلب', 'error');
        }
        
    } catch (error) {
        console.error('Application submission error:', error);
        showToast('حدث خطأ أثناء تقديم الطلب', 'error');
    }
}

// Toast notification system
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Utility function to format phone number
function formatPhoneNumber(phone) {
    return phone.replace(/[^\d+]/g, '');
}

// Utility function to validate file type and size
function validateFile(file, allowedTypes, maxSizeMB) {
    const maxSize = maxSizeMB * 1024 * 1024;
    
    if (!allowedTypes.includes(file.type)) {
        return `نوع الملف غير مسموح به: ${file.type}`;
    }
    
    if (file.size > maxSize) {
        return `حجم الملف كبير جداً (الحد الأقصى: ${maxSizeMB}MB)`;
    }
    
    return null;
}
