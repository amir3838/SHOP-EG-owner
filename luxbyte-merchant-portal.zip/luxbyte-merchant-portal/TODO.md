# Luxbyte Merchant Portal - Build Plan Checklist

Status: In progress

## Phase 0: Project Scaffolding
- [x] package.json with scripts
- [x] tsconfig.json
- [x] .gitignore
- [x] .env.example
- [x] Prisma schema
- [ ] README (AR/EN)

## Phase 1: Backend Core
- [ ] src/config/env.ts (env loading/validation)
- [ ] src/prisma/client.ts (Prisma client singleton)
- [ ] src/middlewares/errorHandler.ts
- [ ] src/middlewares/rateLimit.ts
- [ ] src/utils/govCity.ts (citiesByGov + Qalyubia validation)
- [ ] src/utils/validators.ts (Zod schemas)
- [ ] src/utils/crypto.ts (token/hash helpers)
- [ ] src/services/email/EmailService.ts
- [ ] src/services/email/ResendEmailService.ts
- [ ] src/services/email/SmtpEmailService.ts
- [ ] src/services/verification.ts (create/confirm + attempts/expiry)
- [ ] src/services/storage/SupabaseStorage.ts (S3-compatible presigned)
- [ ] src/services/notifications.ts (notify team on new application)
- [ ] src/routes/verify.ts (POST /verify/send, POST /verify/confirm)
- [ ] src/routes/uploads.ts (POST /uploads/sign)
- [ ] src/routes/applications.ts (POST, GET by id, GET list, PATCH)
- [ ] src/routes/admin.ts (login, me, audit, change status)
- [ ] src/index.ts (Express app, security, static, routes, gzip)

## Phase 2: Frontend (Vanilla HTML/CSS/JS, RTL)
- [ ] public/assets/README.md (place logo.png here)
- [ ] public/css/style.css (RTL/responsive/brand)
- [ ] public/js/toast.js
- [ ] public/js/api.js (fetch wrapper + CSRF)
- [ ] public/js/cities.js (citiesByGov)
- [ ] public/js/map.js (Leaflet + reverse geocode)
- [ ] public/js/main.js (splash)
- [ ] public/js/register.js (wizard + validations + uploads)
- [ ] public/index.html (splash + "إنشاء حساب جديد")
- [ ] public/register.html (4-steps form)
- [ ] public/verify.html (verify page)
- [ ] public/admin/login.html
- [ ] public/admin/dashboard.html
- [ ] public/css/admin.css
- [ ] Leaflet integration (CDN)

## Phase 3: Database & Seed
- [ ] npm run prisma:generate
- [ ] npm run migrate (migrate:dev for development)
- [ ] scripts/seed.ts (create initial admin)
- [ ] npm run seed

## Phase 4: Security & Performance
- [ ] Helmet + CORS + cookie-parser + csurf (admin)
- [ ] Rate limiting for verify endpoints
- [ ] JWT HttpOnly cookies for admin
- [ ] Compression (gzip)
- [ ] Optional Turnstile integration

## Phase 5: Tests
- [ ] tests/verify.test.ts (send/confirm expiry/attempts)
- [ ] tests/validators.test.ts (Zod validators)
- [ ] tests/applications.test.ts (POST validations, filters)

## Phase 6: Docker & Compose
- [ ] Dockerfile
- [ ] docker-compose.yml
- [ ] npm scripts: dev, build, start, migrate, seed, test

## Phase 7: Documentation
- [ ] README.md (AR/EN): setup, env, Supabase, email, run, deploy, admin, security notes.

Notes:
- Bucket: merchant-documents (Supabase S3 compatible)
- S3 keys provided in .env.example; add real DATABASE_URL passwords and email provider keys later.
- Public URL (APP_URL) defaults to http://localhost:4000 (server also serves static frontend).
