import 'dotenv/config';
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'online.medicines.cosmetics.supplements1@outlook.com';
  const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
  const role = (process.env.ADMIN_ROLE as 'reviewer' | 'admin') || 'admin';

  const passHash = await bcrypt.hash(ADMIN_PASSWORD, 10);

  const admin = await prisma.admin.upsert({
    where: { email: ADMIN_EMAIL },
    update: { passHash, role },
    create: { email: ADMIN_EMAIL, passHash, role }
  });

  // eslint-disable-next-line no-console
  console.log('Seed done. Admin ->', { email: admin.email, role: admin.role });
}

main()
  .catch((e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
