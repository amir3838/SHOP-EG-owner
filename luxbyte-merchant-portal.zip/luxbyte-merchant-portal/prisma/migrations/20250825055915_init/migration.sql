-- CreateEnum
CREATE TYPE "lb_portal"."ApplicationType" AS ENUM ('pharmacy', 'supermarket', 'restaurant');

-- CreateEnum
CREATE TYPE "lb_portal"."ApplicationStatus" AS ENUM ('pending', 'in_review', 'approved', 'rejected');

-- CreateEnum
CREATE TYPE "lb_portal"."DocumentKind" AS ENUM ('sign_photo', 'ph_license', 'ph_cr', 'ph_id', 'sm_id', 'sm_cr', 'sm_tax');

-- CreateEnum
CREATE TYPE "lb_portal"."VerificationStatus" AS ENUM ('pending', 'verified', 'expired');

-- CreateEnum
CREATE TYPE "lb_portal"."AdminRole" AS ENUM ('reviewer', 'admin');

-- CreateTable
CREATE TABLE "lb_portal"."applications" (
    "id" TEXT NOT NULL,
    "type" "lb_portal"."ApplicationType" NOT NULL,
    "storeName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "gov" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "addressText" TEXT NOT NULL,
    "lat" DOUBLE PRECISION NOT NULL,
    "lng" DOUBLE PRECISION NOT NULL,
    "status" "lb_portal"."ApplicationStatus" NOT NULL DEFAULT 'pending',
    "reviewNote" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "applications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lb_portal"."documents" (
    "id" TEXT NOT NULL,
    "applicationId" TEXT NOT NULL,
    "kind" "lb_portal"."DocumentKind" NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "mime" TEXT NOT NULL,
    "size" INTEGER NOT NULL,
    "sha256" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lb_portal"."verifications" (
    "id" TEXT NOT NULL,
    "requestId" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "status" "lb_portal"."VerificationStatus" NOT NULL DEFAULT 'pending',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "verifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lb_portal"."admins" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "passHash" TEXT NOT NULL,
    "role" "lb_portal"."AdminRole" NOT NULL DEFAULT 'reviewer',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "admins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "lb_portal"."audit_logs" (
    "id" TEXT NOT NULL,
    "actor" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "entity" TEXT NOT NULL,
    "meta" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "applications_email_key" ON "lb_portal"."applications"("email");

-- CreateIndex
CREATE INDEX "applications_type_idx" ON "lb_portal"."applications"("type");

-- CreateIndex
CREATE INDEX "applications_status_idx" ON "lb_portal"."applications"("status");

-- CreateIndex
CREATE INDEX "applications_gov_city_idx" ON "lb_portal"."applications"("gov", "city");

-- CreateIndex
CREATE INDEX "documents_applicationId_idx" ON "lb_portal"."documents"("applicationId");

-- CreateIndex
CREATE UNIQUE INDEX "verifications_requestId_key" ON "lb_portal"."verifications"("requestId");

-- CreateIndex
CREATE INDEX "verifications_email_idx" ON "lb_portal"."verifications"("email");

-- CreateIndex
CREATE INDEX "verifications_status_idx" ON "lb_portal"."verifications"("status");

-- CreateIndex
CREATE UNIQUE INDEX "admins_email_key" ON "lb_portal"."admins"("email");

-- CreateIndex
CREATE INDEX "audit_logs_entity_idx" ON "lb_portal"."audit_logs"("entity");

-- AddForeignKey
ALTER TABLE "lb_portal"."documents" ADD CONSTRAINT "documents_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "lb_portal"."applications"("id") ON DELETE CASCADE ON UPDATE CASCADE;
