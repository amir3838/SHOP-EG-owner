import { Router } from 'express';
import { VerifySendSchema, VerifyConfirmSchema } from '../utils/validators.js';
import { createVerification, confirmVerification } from '../services/verification.js';
import { verifySendLimiter, verifyConfirmLimiter } from '../middlewares/rateLimit.js';

const router = Router();

router.post('/send', verifySendLimiter, async (req, res, next) => {
  try {
    const { email } = VerifySendSchema.parse(req.body);
    const { requestId } = await createVerification(email);
    res.json({ requestId });
  } catch (err) {
    next(err);
  }
});

router.post('/confirm', verifyConfirmLimiter, async (req, res, next) => {
  try {
    const { requestId, token } = VerifyConfirmSchema.parse(req.body);
    await confirmVerification(requestId, token);
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

export default router;
